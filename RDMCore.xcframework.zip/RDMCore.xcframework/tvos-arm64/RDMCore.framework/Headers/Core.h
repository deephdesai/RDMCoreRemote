//
//  Core.h
//  Core
//
//  Created by alexpezzi on 2019-10-30.
//  Copyright © 2019 Rogers Digital Media. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RDMCore.
FOUNDATION_EXPORT double RDMCoreVersionNumber;

//! Project version string for RDMCore.
FOUNDATION_EXPORT const unsigned char RDMCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RDMCore/PublicHeader.h>


